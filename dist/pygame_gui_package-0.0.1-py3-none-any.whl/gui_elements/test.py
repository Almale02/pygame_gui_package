import pygame
print("111", end="")
